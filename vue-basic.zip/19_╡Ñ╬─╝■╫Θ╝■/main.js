//创建vm
import App from './App';
//如果文件
new Vue({
    el: '#root',
    template:`<App></App>`,
    components:{
        App
    }
});

